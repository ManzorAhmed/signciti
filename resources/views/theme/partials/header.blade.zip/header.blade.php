<style>
.btn-primary {
    color: #fff;
    background-color: #0069d9cc;
    border-color: #0069d9cc;
}
.btn-primary:hover {
    background-color: #0069d9;
}
a
{
    color: #4b4b4b;
}
a:hover {
    color: black !important;
    text-decoration: none !important;
}
.w-40
{
    width:40%;
}
</style>
<section class="header-main border-bottom" style="background-color: #f6f6f6;">
    <div class="container-fluid">
        <div class="row align-items-center d-none d-lg-flex">
            <div class="col-xl-4 col-lg-3">
                <a href="{{route('home')}}" class="brand-wrap" data-abc="true">
                    <img class="w-40 pt-2" src="@isset($setting['admin_logo']) {{ asset('uploads/'.$setting['admin_logo']) }}@endisset">
                </a>
            </div>
            <div class="col-xl-5 col-lg-5 d-flex justify-content-end">
                <form action="#" class="search-wrap px-2 w-75">
                    <div class="input-group border border-warning rounded">
                        <div></div>
                        <input type="text" class="form-control search-form rounded border-0" placeholder="Search">
                        <div class="input-group-append">
                            <button class="btn btn-warning bg-warning search-button" type="submit"><i class="fa fa-search" style="color: black;"></i></button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-xl-3 col-lg-4 d-flex justify-content-center">
                <a class="text-decoration-none zoom test-muted align-self-center m-1" href="tel:718-850-4110"><i class="fa fa-phone mr-1" aria-hidden="true" style="font-size: 22px;"></i> 718-850-4110</></a>
                @auth
                    <a href="{{route('logout')}}" type="button" class="btn btn-warining bg-warning text-white m-1">Logout</a>
                @else
                    <a href="{{route('login')}}" type="button" class="btn btn-warining bg-warning m-1 text-white">Sign In</a>
                @endauth
                <span class="zoom align-self-center m-1"><i style="font-size: 22px;" class="fa fa-shopping-basket" aria-hidden="true"></i>
            </div>
        </div>
    </div>
</section>
